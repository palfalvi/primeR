library(highcharter)
options(highcharter.debug = TRUE)
options(highcharter.verbose = TRUE)
options(highcharter.theme = hc_theme_smpl())
