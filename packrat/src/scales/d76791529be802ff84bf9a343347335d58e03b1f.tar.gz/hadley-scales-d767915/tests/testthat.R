library(testthat)
library(scales)

test_check("scales")
