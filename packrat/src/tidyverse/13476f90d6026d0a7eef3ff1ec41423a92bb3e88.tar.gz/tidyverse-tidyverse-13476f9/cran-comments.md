This is a minor release moving an imported package to suggests, and
fixing R CMD check NOTEs

---

## Test environments
* local OS X install, R 3.3.2
* ubuntu 12.04 (on travis-ci), R 3.3.2
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 0 notes

## Reverse dependencies

I ran R CMD check on all 5 revdeps. I did not see any problems.

Check summary at https://github.com/tidyverse/tidyverse/tree/master/revdep
